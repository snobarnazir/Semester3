#include "Cupboard.h"


/*Cupboard::Cupboard()
{
    color=0;
}*/

int Cupboard::getArea()
{
    return length*width;
}

bool Cupboard::modifyCupboard()
{
    
    cout<<"Enter the color of your choice";
    color = 3;
    return true;
    
}
void Cupboard::changeLength(int len)
{
    length=len;
}
void Cupboard::changeWidth(int wid)
{
    width=wid;
}

int main()
{
    Cupboard myFavouriteCupbord,cupboardOfParents,cupboardOfSiblings;
    myFavouriteCupbord.changeLength(10);
    myFavouriteCupbord.changeWidth(10);
    cout<<"Area of my my favourite cupboard is "<<myFavouriteCupbord.getArea()<<endl;
    cout<<"Area of my parents cupboard is "<<cupboardOfParents.getArea()<<endl;
    cout<<"Area of my siblings cupboard is "<<cupboardOfSiblings.getArea()<<endl;
    
    

    return 0;
}
