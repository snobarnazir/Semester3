#include "Cupboard.h"

class Cupboard
{
    
private:

int length;
int width;
int partitions;
int color;
int weight;
float price;

public:

void changeLength(int len);
void changeWidth(int wid);
int getArea();
bool modifyCupboard();
    
    
};